create schema IPL_MGMT_SYSTEM;

create table IPL_MGMT_SYSTEM.Users(UserId int constraint UserId_PK primary key, UserName varchar(30),Password varchar(15),FirstName varchar(30), LastName varchar(30));


create table IPL_MGMT_SYSTEM.Roles(RoleId int  constraint RoleId_PK primary key,RoleName varchar(30)); 
create table IPL_MGMT_SYSTEM.UserRoles(UserId int  constraint UserId_FK foreign key references IPL_MGMT_SYSTEM.Users(UserId),RoleId int  constraint RoleId_FK foreign key references IPL_MGMT_SYSTEM.Roles(RoleId));

create table IPL_MGMT_SYSTEM.Team(TeamId int  constraint TeamId_PK primary key,TeamName varchar(30),HomeGround varchar(40),Owners varchar(30),LogoImage image);

create table  IPL_MGMT_SYSTEM.Speciality(SpecialityId int  constraint SpecialityId_PK primary key,SpecialityDescription varchar(50));


create table IPL_MGMT_SYSTEM.Player(PlayerId int  constraint PlayerId_PK primary key,
TeamId int  constraint TeamId_FK foreign key references IPL_MGMT_SYSTEM.Team(TeamId),
PlayerName varchar(30),Age int,SpecialityId int  constraint SpecialityId_FK foreign key references  IPL_MGMT_SYSTEM.Speciality(SpecialityId));

create table  IPL_MGMT_SYSTEM.PlayerPhoto(playerId int  constraint PlayerId_FK foreign key references  IPL_MGMT_SYSTEM.Player(PlayerId), Photo image);

create table  IPL_MGMT_SYSTEM.Stat(TeamId int  constraint Stat_TeamId_FK foreign key references  IPL_MGMT_SYSTEM.Team(TeamId),
Played int,Won int,Lost int,Tied int, NR int, NetRR float ,Pts int ,FromPoints int);

create table  IPL_MGMT_SYSTEM.Venue(VenueId int  constraint VenueId_PK primary key,Location varchar(30),VenueDescription varchar(40));
create table  IPL_MGMT_SYSTEM.Match(MatchId int  constraint MatchId_PK primary key,TeamOneId int ,TeamTwoId int ,VenueId int, PhotoGroupId int);


create table  IPL_MGMT_SYSTEM.MatchPhoto(MatchPhotoId int  constraint matchPhotoId_PK primary key,
MatchId int  constraint MatchId_FK foreign key references  IPL_MGMT_SYSTEM.Match(MatchId),MPhoto image);

create table  IPL_MGMT_SYSTEM.Schedule(ScheduleId int  constraint ScheduleId_PK primary key,
MatchId int  constraint Schedule_MatchId_FK foreign key references  IPL_MGMT_SYSTEM.Match(MatchId),
Schedule_VenueId int foreign key references  IPL_MGMT_SYSTEM.Venue(VenueId),ScheduleDate date,StartTime time ,EndTime time);

create table  IPL_MGMT_SYSTEM.TicketCategory(TicketCategoryId int constraint TicketCategoryId_PK primary key,TicketCategoryName varchar(30),TicketDescription varchar(40));


create table  IPL_MGMT_SYSTEM.Ticket(TicketId int constraint TicketId_PK primary key,
MatchId int constraint Ticket_MatchId_FK foreign key references  IPL_MGMT_SYSTEM.Match(MatchId),
TicketCategoryId int constraint TicketCategoryId_FK foreign key references IPL_MGMT_SYSTEM.TicketCategory(TicketCategoryId),Price int);

create table   IPL_MGMT_SYSTEM.News(NewsId int ,Newsdate date,
MatchId int constraint News_Matchid_FK foreign key references   IPL_MGMT_SYSTEM.Match(MatchId),NewsDescription varchar(30),
MatchPhotoId int constraint News_MatchphotoId_FK foreign key references   IPL_MGMT_SYSTEM.MatchPhoto(MatchPhotoId));